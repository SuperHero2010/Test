function onCreate()
	makeLuaSprite('bg', 'Exterminus', -4200, -2700);
	setLuaSpriteScrollFactor('bg', 1, 1);
	scaleObject('bg', 2, 2);
	addLuaSprite('bg', false);

	initLuaShader("Exterminus")
	setSpriteShader("bg", "Exterminus")
end

function onUpdate(elapsed)
	setShaderFloat('bg', 'iTime', getSongPosition()/600)
end
local targetCharacter = 'ommetaphobia-shake'

function opponentNoteHit(id, direction, noteType, isSustainNote)
    if getProperty('dad.curCharacter') == targetCharacter then
        triggerEvent('Screen Shake', '0.1, 0.1', '')
    end
end

-- If the character is the player instead of the opponent, use this instead:
--[[
function goodNoteHit(id, direction, noteType, isSustainNote)
    if getProperty('boyfriend.curCharacter') == targetCharacter then
        triggerEvent('Screen Shake', '0.1, 0.1', '')
    end
end
]]

function onEvent(name, value1, value2)
   if name == 'bgchange' then
	makeLuaSprite(value2,value1,-9000,-7000)
	addLuaSprite(value2,false)
    addGlitchEffect(value1, 2, 6);
	setLuaSpriteScrollFactor(value2, 0.5, 0.5)
    scaleObject(value2, 4, 4)
    
    end
end
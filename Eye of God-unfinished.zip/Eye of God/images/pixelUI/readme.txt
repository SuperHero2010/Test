Just like the normal ratings folder, put your pixel rating sprites in here!

To ensure no issues, the following sprites must be in this folder:
perfect-pixel.png
sick-pixel.png
good-pixel.png
bad-pixel.png
shit-pixel.png
All pngs from num0-pixel.png to num9-pixel.png

hitStrings, fcStrings and judgeCountStrings text files are not needed, only the normal folder needs them.

Also, don't worry about adding a list.txt, as long as the folder name matches with the normal folder name the game will automatically pick it up.
To add rating sprites, make a new folder with the name of your rating sprites (replace spaces with a "-"!) and put your rating sprites in there!

To ensure no issues, these sprites must be in each folder:
perfect.png
sick.png
good.png
bad.png
shit.png
All pngs from num0.png to num9.png

To add pixel rating sprites, see images/pixelUI/ratings.